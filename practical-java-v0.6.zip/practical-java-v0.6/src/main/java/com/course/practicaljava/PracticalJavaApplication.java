package com.course.practicaljava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticalJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PracticalJavaApplication.class, args);
	}

}
